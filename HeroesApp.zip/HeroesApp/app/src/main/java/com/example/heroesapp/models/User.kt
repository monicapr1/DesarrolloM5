package com.example.heroesapp.models

data class User(val email:String,val password:String)