package com.example.barcodeapp.data.dao

interface ProductDAO {
}