package com.example.barcodeapp.solid

class GeneradorFacturas{

    fun generarFacturas(){

    }
}
class Env