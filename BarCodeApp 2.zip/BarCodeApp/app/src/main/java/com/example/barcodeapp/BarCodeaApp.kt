package com.example.barcodeapp
import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BarCodeaApp: Application() {
}